<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Pagina iniziale</title>
    <meta name="author" content="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="css/style.css" rel="stylesheet">
</head>

<body>

<p>Hello, world!</p>



<form action="upload.php" method="post" enctype="multipart/form-data">
    Seleziona la chiave da caricare
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Carica chiave" name="submit">
</form>


<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>-->
<!--<script src="js/script.js"></script>-->
</body>

</html>

