<?php
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
$target_dir = "/root/ca/intermediate/csr/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
echo $target_file."<br/>";
$uploadOk = 0;
$fileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
        $uploadOk = 1;
        echo "File ricevuto<br/>";
    } else {
        echo "Errore, file mancante<br/>";
        $uploadOk = 0;
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.<br/>";
    $uploadOk = 0;
}

// Check file size
if ($_FILES["fileToUpload"]["size"] > 50000) {
    echo "Sorry, your file is too large.<br/>";
    $uploadOk = 0;
}

// Allow certain file formats
if($fileType != "pem") {
    echo "Il file deve essere una chiave<br/>";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "File non caricato, riprova";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.<br/>";
    } else {
        exit("Sorry, there was an error uploading your file.<br/>");
    }
}

$csrdata = file_get_contents($target_file, true);

//var_dump(openssl_pkey_get_details($csrdata));

// We will sign the request using our own "certificate authority"
// certificate.  You can use any certificate to sign another, but
// the process is worthless unless the signing certificate is trusted
// by the software/users that will deal with the newly signed certificate

// We need our CA cert and its private key
$cacert = file_get_contents("/root/ca/intermediate/certs/intermediate.cert.pem");
$privkey = array(file_get_contents("/root/ca/intermediate/private/intermediate.key.pem"), "intermediate2020");

$usercert = openssl_csr_sign($csrdata, $cacert, $privkey, 90, array('config' => '/root/ca/intermediate/openssl.cnf', 'digest_alg'=>'sha256',  'extensions' => 'server_cert') );

// Now display the generated certificate so that the user can
// copy and paste it into their local configuration (such as a file
// to hold the certificate for their SSL server)
openssl_x509_export($usercert, $certout);
//echo $certout."<br/><br/>";

file_put_contents(str_replace(".csr.pem", ".cert.pem", $target_file), $certout);

// Show any errors that occurred here
while (($e = openssl_error_string()) !== false) {
    echo $e . "\n";
}
//unlink($target_file);
?>