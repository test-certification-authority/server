
<html>
    <head>
        <title>Caricamento Certificato</title>
            <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<style>
		body{
			background-color: rgb(200,200,200);
			padding: 10px;
		}
		.container{
			background-color:white;
			padding:30px;
			min-height: 100%;
		}
	</style>

    </head>
<body>
    <script>
    function download(url, filename) {
fetch(url).then(function(t) {
    return t.blob().then((b)=>{
        var a = document.createElement("a");
        a.href = URL.createObjectURL(b);
        a.setAttribute("download", filename);
        a.click();
    }
    );
});
}

</script>
    <div class="container">
    	<div class="row"><a href="http://test-certification-authority.it/">&lt; Torna al sito</a></div>
    	<h1>Creazione certificato</h1>
    	<hr/>
    	<?php 
	 echo "<h3>Prima di iniziare</h3> <a href='javascript:download(\"/static/ca-chain.cert.pem\", \"ca-chain.cert.pem\");'  class='btn btn-success'>Scarica il certificato della Certification Authority</a>";
	?>
	<hr>
	<p>
		Un CSR (Certificate Signing Request – Richiesta di Certificato di Firma) è un codice di testo criptato che viene utilizzato per la creazione e l'assegnazione di un certificato
	</p>
	<blockquote style="margin-bottom:30px;">
		<span style="font-size:xx-large; line-height: xx-large; vertical-align: middle; margin-right:10px;">Come si crea un CSR?</span><a href = "https://test-certification-authority.it/" class="btn btn-secondary btn-small">Scoprilo qua</a>
	</blockquote>
	<hr>
	



<form action="upload.php" method="post" enctype="multipart/form-data" style="margin-top:20px; padding:40px; background-color:rgb(242,242,242);">
	<div class="form-group">
	<fieldset>
	<legend>Benvenuto, carica il tuo File in formato  .csr.pem per ottenere il tuo certificato</legend><br />
    <input type="file" name="fileToUpload" id="fileToUpload" class="form-control-file"><hr>
     <label><div style="display: inline-block; width: 30px; margin-right: 5px; justify-content: top; vertical-align: top;padding-top:5px;"><input type="checkbox" required name="gdpr"></div><div style="display: inline-block; width: calc(100% - 40px) ; vertical-align: top;">Acconsento alla vostra <a href="/wordpress/privacy-policy">informativa sulla privacy</a> e Autorizzo il trattamento dei miei dati personali ai sensi del Decreto Legislativo 30 giugno 2003, n. 196 “Codice in materia di protezione dei dati personali” e del GDPR (Regolamento UE 2016/679).</div></label><br /><hr />
    <input type="submit" value="Crea Certificato"  name="submit" class="btn btn-primary mb-2" required><br />
   
	</fieldset>
	</div>
</form>

<div class="row">
		<a href="http://test-certification-authority.it/">&lt; Torna al sito</a>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<!--<script src="js/script.js"></script>-->
<!-- Customerly Integration Code -->
<!-- Customerly Integration Code -->
<script>
    window.customerlySettings = {
        app_id: "e22eae9f"
    };
    !function(){function e(){var e=t.createElement("script");
    e.type="text/javascript",e.async=!0,
    e.src="https://widget.customerly.io/widget/e22eae9f";
    var r=t.getElementsByTagName("script")[0];r.parentNode.insertBefore(e,r)}
    var r=window,t=document,n=function(){n.c(arguments)};
    r.customerly_queue=[],n.c=function(e){r.customerly_queue.push(e)},
    r.customerly=n,r.attachEvent?r.attachEvent("onload",e):r.addEventListener("load",e,!1)}();
</script>
</body>

</html>

