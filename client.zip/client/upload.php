
<html>
    <head>
        <title>Caricamento Certificato</title>
            <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    </head>
    
    <style>
        body{
            background-color: rgb(200,200,200);
            padding: 10px;
        }
        .container{
            background-color:white;
            padding:30px;
            min-height: 100%;
        }
    </style>
<body>
    <script>
    function download(url, filename) {
fetch(url).then(function(t) {
    return t.blob().then((b)=>{
        var a = document.createElement("a");
        a.href = URL.createObjectURL(b);
        a.setAttribute("download", filename);
        a.click();
    }
    );
});
}

</script>
    <div class="container">
<h1>Stiamo Certificando il tuo file</h1>
<?php
$dir             = "/root/ca/intermediate";            
$certs           = $dir ."/certs/";           
$crl_dir         = $dir."/crl/";              
$csr_dir         = $dir."/csr/";              
$database        = $dir."/index.txt ";       
$new_certs_dir   = $dir."/newcerts/";        

$certificate     = $dir."/certs/intermediate.cert.pem"; 
$serial          = $dir."/serial";           
$crlnumber       = $dir."/crlnumber ";       
$RANDFILE        = $dir."/private/.rand";    
$crl             = $dir."/crl/intermediate.crl.pem"; 
$private_key     = $dir."/private/intermediate.key.pem";

$target_file = $csr_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 0;
$fileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

if(isset($_POST["submit"])) {
        $uploadOk = 1;
        echo "<div class='alert alert-success'>File ricevuto</div>";
    } else {
        errorMessage();

        die("<div class=\"alert alert-danger\">Errore, file mancante</div>");
        $uploadOk = 0;
}

function errorMessage($msg =""){
    echo "<div class='alert alert-danger'><h4>C'e stato un errore</h4><p><p>$msg</p>";
    while (($e = openssl_error_string()) !== false) {
        $e . "\n";
    }
    echo "</p> <a class='btn btn-danger' href='/client/index.php'>Riprova</a></div>";
}


if ($_FILES["fileToUpload"]["size"] > 50000) {
        errorMessage();
    die("<div class=\"alert alert-danger\">Mi dispiace, il file da te creato è troppo grande.</div>");

}


if($fileType != "pem") {
    errorMessage();
    die( "<div class=\"alert alert-danger\">Il file deve essere una chiave .pem</div>");

}else{
    if(strtolower(pathinfo(basename($target_file, '.pem'), PATHINFO_EXTENSION)) != "csr"){
        die( "<div class=\"alert alert-danger\">Il file deve essere un CSR (.csr.pem)</div>");
    }
}



if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo  "<div class=\"alert alert-success\">Il file ". basename( $_FILES["fileToUpload"]["name"]). " è stato caricato correttamente.</div>";
} else {
        errorMessage();
    die("<div class=\"alert alert-danger\">Ci dispiace abbiamo avuto un problema con il caricamento del tuo file.</div>");
}




$link = fopen($target_file, 'r');
$data = fread($link, filesize($target_file));
fclose($link);



$cacert = file_get_contents($certificate);

$privkey = array(file_get_contents($private_key), "intermediate2020");


$link = fopen($dir . "/openssl.cnf", 'r');
$conf = fread($link, filesize($target_file));
fclose($link);
$configParams = array(
'md'=>'sha256',
'digest_alg' =>'sha256',
'config' => $dir . "/openssl.cnf",
'notext',
'x509_extensions' => 'server_cert',

);
$pwdexp = "team";
$serialC = mt_rand(1, 2147483647) . mt_rand(1, 2147483647);


$certin = openssl_csr_sign($data, $cacert, $privkey, 90, $configParams, $serialC );
usleep(1);
if(openssl_x509_export($certin, $certout)){

$certFile = $certs. basename($target_file, '.csr.pem'). ".cert.pem";
file_put_contents($certFile , $certout);
    if(file_exists($certFile))
    {
        file_put_contents( $serial , $serialC.PHP_EOL, FILE_APPEND | LOCK_EX);
        openssl_pkcs12_export_to_file($certout, $certs. basename($target_file, '.csr.pem').".p12", $privkey);
        copy($certFile, "../static/" . basename($target_file, '.csr.pem') . ".cert.pem") or die("<div class=\"alert alert-danger\">Impossibile copiare il file");

        echo "<a href='javascript:download(\"/static/". basename($target_file, '.csr.pem') . ".cert.pem\", 
        \"".basename($target_file, '.csr.pem') . ".cert.pem\");' class='btn btn-success'>Scarica il tuo certificato</a>";

        echo "&nbsp; <a href='javascript:download(\"/static/ca-chain.cert.pem\", \"ca-chain.cert.pem\");'  class='btn btn-success'>Scarica il certificato della Certification Authority</a>";
           echo "<br /><br /><p><a class='btn btn-primary' href='/wordpress/'>Scopri come firmare un documento</a></p>";
           echo "<script>download(\"/static/". basename($target_file, '.csr.pem') . ".cert.pem\", 
        \"".basename($target_file, '.csr.pem') . ".cert.pem\");
         </script>";

         unlink( $target_file);
    }else{
        errorMessage("Errore nella creazione del certificato");
        unlink( $target_file);
    }
}else{
    errorMessage("Errore Esportazione");
    unlink($target_file);
}

?>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</div>

<!-- Customerly Integration Code -->
<script>
    window.customerlySettings = {
        app_id: "e22eae9f"
    };
    !function(){function e(){var e=t.createElement("script");
    e.type="text/javascript",e.async=!0,
    e.src="https://widget.customerly.io/widget/e22eae9f";
    var r=t.getElementsByTagName("script")[0];r.parentNode.insertBefore(e,r)}
    var r=window,t=document,n=function(){n.c(arguments)};
    r.customerly_queue=[],n.c=function(e){r.customerly_queue.push(e)},
    r.customerly=n,r.attachEvent?r.attachEvent("onload",e):r.addEventListener("load",e,!1)}();
</script>
</body>

</html>
